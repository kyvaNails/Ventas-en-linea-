import { useState } from "react";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient("https://TU_URL_SUPABASE.supabase.co", "TU_CLAVE_PUBLICA");

export default function Home() {
  const [products, setProducts] = useState([]);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("");
  const [receipt, setReceipt] = useState("");
  const [saving, setSaving] = useState(false);

  const addProduct = () => {
    if (!name || !price || !quantity) return;
    const newProduct = {
      name,
      price: parseFloat(price),
      quantity: parseInt(quantity),
    };
    setProducts([...products, newProduct]);
    setName("");
    setPrice("");
    setQuantity("");
  };

  const removeProduct = (indexToRemove) => {
    const updated = products.filter((_, index) => index !== indexToRemove);
    setProducts(updated);
  };

  const total = products.reduce((sum, product) => sum + product.price * product.quantity, 0);

  const generateReceipt = async () => {
    if (products.length === 0) return;
    setSaving(true);
    let receiptText = "*** RECIBO DE COMPRA ***\n\n";
    products.forEach((product) => {
      receiptText += `${product.quantity} x ${product.name} @ $${product.price.toFixed(2)} = $${(product.price * product.quantity).toFixed(2)}\n`;
    });
    receiptText += `\nTotal a pagar: $${total.toFixed(2)}\n\n¡Gracias por su compra!`;
    setReceipt(receiptText);

    const { error } = await supabase.from("ventas").insert([{
      productos: JSON.stringify(products),
      total: total,
      fecha: new Date().toISOString(),
    }]);

    if (error) {
      alert("Error al guardar en la base de datos");
      console.error(error);
    } else {
      alert("Venta guardada exitosamente");
    }

    setSaving(false);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Venta en Línea</h1>
      <div>
        <input placeholder="Nombre del producto" value={name} onChange={(e) => setName(e.target.value)} />
        <input type="number" placeholder="Precio" value={price} onChange={(e) => setPrice(e.target.value)} />
        <input type="number" placeholder="Cantidad" value={quantity} onChange={(e) => setQuantity(e.target.value)} />
        <button onClick={addProduct}>Agregar</button>
      </div>
      <ul>
        {products.map((product, index) => (
          <li key={index}>
            {product.quantity} x {product.name} @ ${product.price.toFixed(2)} = ${(product.price * product.quantity).toFixed(2)}
            <button onClick={() => removeProduct(index)}>Eliminar</button>
          </li>
        ))}
      </ul>
      <div>Total a pagar: ${total.toFixed(2)}</div>
      <button onClick={generateReceipt} disabled={saving}>{saving ? "Guardando..." : "Generar Recibo y Guardar"}</button>
      {receipt && <pre>{receipt}</pre>}
    </div>
  );
}